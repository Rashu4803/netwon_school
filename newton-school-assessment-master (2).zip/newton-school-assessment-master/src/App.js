import "./App.css";
import { useEffect, useRef, useState } from "react";
function App() {
  const [count, setCount] = useState(0);
  const previousVal = useRef(0);
  const renderCount = useRef(0);
  const newRef = useRef(null);

  useEffect(() => {
    previousVal.current = count;
  }, [count]);

  useEffect(() => {
    renderCount.current = renderCount.current + 1;
  });
  const handleClickDecrement= () => {
    setCount((count) => count - 1);
  };

  const handleClickIncrement = () => {
    setCount((count) => count + 1);
  };

  const executeScroll = () => {
    newRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  return (
    <div className="App">
      <div className="App-header">
        <h1>Let's learn useRef Hook</h1>
        <div>1.It can be used to access a DOM element directly.</div>
        <div>2.If we tried to count how many times our application renders using the useState Hook, we would be caught in an infinite loop since this Hook itself causes a re-render.
To avoid this, we can use the useRef Hook.</div>
        <div>3.In useRef we can add a ref attribute to an element to access it directly in the DOM.</div>
        <div>4.The useRef Hook allows you to persist values between renders.</div>
        <div>5.useRef() only returns one item. It returns an Object called current.</div>
        <div>6.The useRef Hook can also be used to keep track of previous state values.</div>
        <div className="btns">
          <button data-cy="decrement" className="btn_ope" onClick={handleClickDecrement}>
            decrement
          </button>
          <button data-cy="increment" className="btn_ope" onClick={handleClickIncrement}>
            increment
          </button>
        </div>
        <div className="second-div">
          <div data-cy="counter">Current Value : {count}</div>
          Previous Value : {previousVal.current}
          <div>Number of times component render: {renderCount.current}</div>
        </div>
        <button className="btn" onClick={executeScroll}>
          Click here to go a new-div
        </button>
      </div>

      <div ref={newRef} className="new-div">
               new-div.
      </div>
    </div>
  );
}

export default App;
